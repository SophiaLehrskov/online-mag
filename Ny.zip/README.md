#Projekt: Online Magazine

Her er mit online magazine, der hander om hvordan man kan leve livet på budget, uden at gå for meget på kompromis.

Se fungerende prototype her;http://magasin.sophialehrskov.dk/index.html
